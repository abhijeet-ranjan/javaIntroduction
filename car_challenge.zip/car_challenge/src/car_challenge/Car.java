package car_challenge;

public class Car extends Vehicle {
	private int doors;
	private int engineCapacity;
	
}
