package car_challenge;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
        
		Scanner scan = new Scanner(System.in);
        
        int s = scan.nextInt();
        int e = scan.nextInt();
        int w = scan.nextInt();
        scan.close();
        if(s>=0 && s<=80){
            if(e >= s && e <=900){
                if(w>= 0 && w<=40){
                    for(int i = s; i <= e;i+=w){
                        System.out.println(i + "\t" + (int)((i-32)/1.8));
                    }
                }
            }
        }			
	}
}
