package car_challenge;

public class Vehicle {

}
