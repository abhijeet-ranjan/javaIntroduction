
public class ComplexNumber {
	private double real;
	private double imaginary;
	
	public ComplexNumber(double real, double imaginary){
		this.real =  real;
		this.imaginary = imaginary;
	}
	public double getReal(){
		return real;
	}
	public double getImaginary(){
		return imaginary;
	}
	public ComplexNumber add(double real, double imaginary){
		    ComplexNumber temp = new ComplexNumber(0,0);
		    temp.real = real + getReal();
		    temp.imaginary = imaginary + getImaginary();
		    return temp;
	}
	public ComplexNumber subtract(double real, double imaginary){
		ComplexNumber temp = new ComplexNumber(0,0);
		temp.real = real - getReal();
		temp.imaginary = imaginary - getImaginary();
		return temp;
	}
	public ComplexNumber	add(ComplexNumber alpha){
		ComplexNumber temp = new ComplexNumber(0,0);
		temp.real = alpha.real + getReal();
		temp.imaginary = alpha.imaginary + getImaginary();
		return temp;
	}
	public ComplexNumber	subtract(ComplexNumber alpha){
		ComplexNumber temp = new ComplexNumber(0,0);
		temp.real = alpha.real - getReal();
		temp.imaginary = alpha.imaginary - getImaginary();
		return temp;
		}
}

